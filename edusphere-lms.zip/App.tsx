import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import Auth from './components/views/Auth';
import Dashboard from './components/views/Dashboard';
import Attendance from './components/views/Attendance';
import Assessments from './components/views/Assessments';
import Notes from './components/views/Notes';
import QuizView from './components/views/Quiz';
import Chatbot from './components/Chatbot';
import { User, View, AttendanceSession, Assessment, Note, Quiz } from './types';
import { 
  INITIAL_USERS, 
  INITIAL_SESSIONS, 
  INITIAL_ASSESSMENTS, 
  INITIAL_NOTES,
  INITIAL_QUIZZES 
} from './constants';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<View>('dashboard');
  
  // Simulated Database State
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [sessions, setSessions] = useState<AttendanceSession[]>(INITIAL_SESSIONS);
  const [assessments, setAssessments] = useState<Assessment[]>(INITIAL_ASSESSMENTS);
  const [notes, setNotes] = useState<Note[]>(INITIAL_NOTES);
  const [quizzes] = useState<Quiz[]>(INITIAL_QUIZZES);

  // Handlers
  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setCurrentView('dashboard');
  };

  const handleRegister = (newUser: User) => {
    setUsers([...users, newUser]);
  };

  const handleLogout = () => {
    setCurrentUser(null);
  };

  const handleMarkAttendance = (sessionId: string, studentId: string) => {
    setSessions(prev => prev.map(s => {
      if (s.id === sessionId && !s.attendees.includes(studentId)) {
        return { ...s, attendees: [...s.attendees, studentId] };
      }
      return s;
    }));
  };

  const handleCreateSession = (newSession: AttendanceSession) => {
    setSessions(prev => [...prev, newSession]);
  };

  const handleUpdateAssessment = (updated: Assessment) => {
    setAssessments(prev => prev.map(a => a.id === updated.id ? updated : a));
  };

  const handleAddNote = (note: Note) => {
    setNotes(prev => [note, ...prev]);
  };

  const handleApproveNote = (noteId: string) => {
    setNotes(prev => prev.map(n => n.id === noteId ? { ...n, isApproved: true } : n));
  };

  if (!currentUser) {
    return <Auth onLogin={handleLogin} users={users} onRegister={handleRegister} />;
  }

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard user={currentUser} assessments={assessments} sessions={sessions} />;
      case 'attendance':
        return <Attendance 
                  user={currentUser} 
                  sessions={sessions} 
                  onMarkAttendance={handleMarkAttendance} 
                  onCreateSession={handleCreateSession}
                />;
      case 'assessments':
        return <Assessments 
                  user={currentUser} 
                  assessments={assessments} 
                  users={users}
                  onUpdateAssessment={handleUpdateAssessment}
                />;
      case 'notes':
        return <Notes 
                  user={currentUser} 
                  notes={notes} 
                  onAddNote={handleAddNote} 
                  onApproveNote={handleApproveNote}
                />;
      case 'quiz':
        return <QuizView quizzes={quizzes} />;
      case 'certificates':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
             <div className="bg-white rounded-xl shadow-sm border p-4">
                <img src="https://picsum.photos/400/300" alt="Cert" className="rounded-lg mb-4 w-full object-cover h-48" />
                <h3 className="font-bold">Web Development Bootcamp</h3>
                <p className="text-sm text-gray-500">Issued: May 2023</p>
                <span className="inline-block bg-indigo-100 text-indigo-800 text-xs px-2 py-1 rounded mt-2">Domain</span>
             </div>
          </div>
        );
      case 'profile':
         return (
             <div className="bg-white max-w-2xl mx-auto rounded-xl shadow-sm border p-8">
                 <div className="flex items-center gap-4 mb-6">
                    <div className="w-20 h-20 rounded-full bg-indigo-100 flex items-center justify-center text-3xl font-bold text-indigo-700">
                        {currentUser.name.charAt(0)}
                    </div>
                    <div>
                        <h2 className="text-2xl font-bold">{currentUser.name}</h2>
                        <p className="text-gray-500">{currentUser.email}</p>
                        <span className="capitalize bg-gray-100 px-2 py-1 rounded text-xs mt-1 inline-block">{currentUser.role}</span>
                    </div>
                 </div>
                 <div className="grid grid-cols-2 gap-4 text-sm">
                    {currentUser.role === 'student' && (
                        <>
                            <div className="p-3 bg-gray-50 rounded">
                                <span className="block text-gray-500 text-xs">Roll Number</span>
                                <span className="font-medium">{currentUser.rollNumber}</span>
                            </div>
                            <div className="p-3 bg-gray-50 rounded">
                                <span className="block text-gray-500 text-xs">Course</span>
                                <span className="font-medium">{currentUser.courseName}</span>
                            </div>
                            <div className="p-3 bg-gray-50 rounded">
                                <span className="block text-gray-500 text-xs">Guardian</span>
                                <span className="font-medium">{currentUser.guardianName || 'N/A'}</span>
                            </div>
                        </>
                    )}
                 </div>
             </div>
         );
      default:
        return <div>View not found</div>;
    }
  };

  return (
    <Layout 
      user={currentUser} 
      currentView={currentView} 
      onChangeView={setCurrentView} 
      onLogout={handleLogout}
    >
      {renderView()}
      <Chatbot user={currentUser} />
    </Layout>
  );
};

export default App;
