import { User, AttendanceSession, Assessment, Note, Quiz, Certificate } from './types';

export const INITIAL_USERS: User[] = [
  {
    id: 'admin-1',
    name: 'Admin User',
    email: 'admin@edusphere.com',
    role: 'admin',
  },
  {
    id: 'teacher-1',
    name: 'Prof. Albus D.',
    email: 'teacher@edusphere.com',
    role: 'teacher',
  },
  {
    id: 'student-1',
    name: 'Harry P.',
    email: 'student@edusphere.com',
    role: 'student',
    rollNumber: 'GRY-001',
    courseName: 'Defense Against Dark Arts',
    admissionYear: '2023',
    phone: '555-0101',
    gender: 'Male',
    community: 'General',
    parentIncome: '50000',
    dob: '1980-07-31',
  }
];

export const INITIAL_SESSIONS: AttendanceSession[] = [
  {
    id: 'sess-1',
    code: 'MAGIC101',
    courseId: 'CS101',
    date: new Date().toISOString(),
    isActive: true,
    attendees: [],
  }
];

export const INITIAL_ASSESSMENTS: Assessment[] = [
  {
    id: 'ass-1',
    studentId: 'student-1',
    courseId: 'CS101',
    semester: 1,
    subject: 'Potions',
    continuousAssessment: 85,
    endSem: 90,
  },
  {
    id: 'ass-2',
    studentId: 'student-1',
    courseId: 'CS101',
    semester: 1,
    subject: 'Transfiguration',
    continuousAssessment: 78,
    endSem: 82,
  },
  {
    id: 'ass-3',
    studentId: 'student-1',
    courseId: 'CS101',
    semester: 2,
    subject: 'Defense Against Dark Arts',
    continuousAssessment: 92,
    endSem: 95,
  }
];

export const INITIAL_NOTES: Note[] = [
  {
    id: 'note-1',
    title: 'Wand Movements Chart',
    description: 'Basic swish and flick guide.',
    url: 'https://picsum.photos/400/600',
    ownerId: 'student-1',
    ownerName: 'Harry P.',
    timestamp: new Date().toISOString(),
    isPublic: true,
    isApproved: true,
    courseId: 'CS101'
  }
];

export const INITIAL_QUIZZES: Quiz[] = [
  {
    id: 'quiz-1',
    title: 'Basic Spells',
    code: 'LUMOS',
    questions: [
      {
        question: 'What is the incantation for light?',
        options: ['Nox', 'Lumos', 'Accio', 'Expelliarmus'],
        correctIndex: 1,
      },
      {
        question: 'What spell disarms an opponent?',
        options: ['Stupefy', 'Avada Kedavra', 'Expelliarmus', 'Protego'],
        correctIndex: 2,
      }
    ]
  }
];

export const INITIAL_CERTIFICATES: Certificate[] = [
  {
    id: 'cert-1',
    studentId: 'student-1',
    title: 'Quidditch Cup Winner',
    category: 'Sports',
    date: '2023-05-20',
    imageUrl: 'https://picsum.photos/600/400'
  }
];
