export type Role = 'student' | 'teacher' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  // Student specific fields
  phone?: string;
  dob?: string;
  parentIncome?: string;
  community?: string;
  courseName?: string;
  address?: string;
  gender?: string;
  guardianName?: string;
  guardianPhone?: string;
  admissionYear?: string;
  rollNumber?: string;
}

export interface AttendanceSession {
  id: string;
  code: string;
  courseId: string;
  date: string;
  isActive: boolean;
  attendees: string[]; // Student IDs
}

export interface Assessment {
  id: string;
  studentId: string;
  courseId: string;
  semester: number;
  subject: string;
  continuousAssessment: number;
  endSem: number;
}

export interface Note {
  id: string;
  title: string;
  description?: string;
  url: string; // Object URL or mock URL
  ownerId: string;
  ownerName: string;
  timestamp: string;
  isPublic: boolean;
  isApproved: boolean; // Teacher approval
  courseId: string;
}

export interface Quiz {
  id: string;
  title: string;
  code: string;
  questions: {
    question: string;
    options: string[];
    correctIndex: number;
  }[];
}

export interface Certificate {
  id: string;
  studentId: string;
  title: string;
  category: 'Event' | 'Domain' | 'Sports';
  date: string;
  imageUrl: string;
}

export type View = 'dashboard' | 'attendance' | 'assessments' | 'notes' | 'quiz' | 'certificates' | 'profile';
