import React, { useState } from 'react';
import { User, Note } from '../../types';
import { UploadCloud, FileText, Check, Eye } from 'lucide-react';

interface NotesProps {
  user: User;
  notes: Note[];
  onAddNote: (note: Note) => void;
  onApproveNote: (noteId: string) => void;
}

const Notes: React.FC<NotesProps> = ({ user, notes, onAddNote, onApproveNote }) => {
  const [uploadTitle, setUploadTitle] = useState('');
  const [uploadDesc, setUploadDesc] = useState('');
  
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && uploadTitle) {
      const newNote: Note = {
        id: `note-${Date.now()}`,
        title: uploadTitle,
        description: uploadDesc,
        url: URL.createObjectURL(file),
        ownerId: user.id,
        ownerName: user.name,
        timestamp: new Date().toISOString(),
        isPublic: true,
        isApproved: false, // Pending teacher approval
        courseId: 'CS101'
      };
      onAddNote(newNote);
      setUploadTitle('');
      setUploadDesc('');
    }
  };

  const visibleNotes = user.role === 'teacher' ? notes : notes.filter(n => n.isApproved || n.ownerId === user.id);

  return (
    <div className="space-y-8">
      {user.role === 'student' && (
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <h3 className="font-bold text-lg mb-4">Share Notes</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <input 
                className="border border-gray-300 rounded-lg p-3 text-sm" 
                placeholder="Document Title" 
                value={uploadTitle}
                onChange={e => setUploadTitle(e.target.value)}
            />
            <input 
                className="border border-gray-300 rounded-lg p-3 text-sm" 
                placeholder="Short description (optional)" 
                value={uploadDesc}
                onChange={e => setUploadDesc(e.target.value)}
            />
             <div className="relative">
                <input 
                    type="file" 
                    onChange={handleFileUpload}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    disabled={!uploadTitle}
                />
                <button 
                    disabled={!uploadTitle}
                    className="w-full h-full bg-indigo-50 border-2 border-dashed border-indigo-200 text-indigo-600 rounded-lg flex items-center justify-center gap-2 font-medium hover:bg-indigo-100 transition-colors disabled:opacity-50"
                >
                    <UploadCloud size={18} /> Upload File
                </button>
             </div>
          </div>
        </div>
      )}

      <div>
        <h2 className="text-xl font-bold text-gray-900 mb-4">Class Notes Repository</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {visibleNotes.map(note => (
                <div key={note.id} className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden hover:shadow-md transition-shadow group">
                    <div className="h-32 bg-gray-100 flex items-center justify-center relative">
                        <FileText size={48} className="text-gray-300 group-hover:scale-110 transition-transform" />
                        {!note.isApproved && (
                             <span className="absolute top-2 right-2 bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full font-medium">Pending</span>
                        )}
                         {note.isApproved && (
                             <span className="absolute top-2 right-2 bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-medium">Verified</span>
                        )}
                    </div>
                    <div className="p-5">
                        <h4 className="font-bold text-gray-900 mb-1 truncate">{note.title}</h4>
                        <p className="text-xs text-gray-500 mb-4">by {note.ownerName} • {new Date(note.timestamp).toLocaleDateString()}</p>
                        <div className="flex items-center justify-between">
                            <a href={note.url} target="_blank" rel="noreferrer" className="text-sm text-indigo-600 font-medium hover:underline flex items-center gap-1">
                                <Eye size={16} /> Preview
                            </a>
                            {user.role === 'teacher' && !note.isApproved && (
                                <button 
                                    onClick={() => onApproveNote(note.id)}
                                    className="bg-green-600 text-white px-3 py-1 rounded-lg text-xs font-bold hover:bg-green-700 flex items-center gap-1"
                                >
                                    <Check size={14} /> Approve
                                </button>
                            )}
                        </div>
                    </div>
                </div>
            ))}
            {visibleNotes.length === 0 && (
                <div className="col-span-full text-center py-10 text-gray-400">
                    No notes found. Be the first to upload!
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default Notes;
