import React, { useState } from 'react';
import { Quiz } from '../../types';
import { Timer, ArrowRight, Check } from 'lucide-react';

interface QuizProps {
  quizzes: Quiz[];
}

const QuizView: React.FC<QuizProps> = ({ quizzes }) => {
  const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);
  const [joinCode, setJoinCode] = useState('');

  const handleJoin = () => {
    const found = quizzes.find(q => q.code === joinCode.toUpperCase());
    if (found) {
        setActiveQuiz(found);
        setFinished(false);
        setScore(0);
        setCurrentQuestion(0);
    } else {
        alert("Invalid Quiz Code");
    }
  };

  const handleAnswer = (index: number) => {
    if (activeQuiz && index === activeQuiz.questions[currentQuestion].correctIndex) {
        setScore(score + 1);
    }
    
    if (activeQuiz && currentQuestion < activeQuiz.questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
    } else {
        setFinished(true);
    }
  };

  if (!activeQuiz) {
      return (
          <div className="flex flex-col items-center justify-center h-[60vh]">
              <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 text-center max-w-md w-full">
                  <div className="w-16 h-16 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
                      <Timer size={32} />
                  </div>
                  <h2 className="text-2xl font-bold mb-2">Quiz Time!</h2>
                  <p className="text-gray-500 mb-6">Enter the game PIN provided by your teacher to join.</p>
                  <input 
                    className="w-full text-center text-2xl tracking-widest border-2 border-gray-300 rounded-xl p-3 mb-4 uppercase font-bold focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none"
                    placeholder="GAME PIN"
                    value={joinCode}
                    onChange={e => setJoinCode(e.target.value)}
                  />
                  <button 
                    onClick={handleJoin}
                    className="w-full bg-gray-900 text-white font-bold py-4 rounded-xl hover:bg-black transition-colors"
                  >
                      Enter
                  </button>
              </div>
          </div>
      );
  }

  if (finished) {
      return (
          <div className="flex flex-col items-center justify-center h-[60vh] animate-in zoom-in duration-300">
               <div className="text-center">
                   <h2 className="text-4xl font-bold text-gray-900 mb-2">Quiz Complete!</h2>
                   <div className="text-9xl font-black text-indigo-600 my-8">
                       {Math.round((score / activeQuiz.questions.length) * 100)}%
                   </div>
                   <p className="text-xl text-gray-600">You scored {score} out of {activeQuiz.questions.length}</p>
                   <button 
                    onClick={() => { setActiveQuiz(null); setJoinCode(''); }}
                    className="mt-8 bg-gray-900 text-white px-8 py-3 rounded-full font-bold hover:bg-black transition-colors"
                   >
                       Back to Home
                   </button>
               </div>
          </div>
      );
  }

  const question = activeQuiz.questions[currentQuestion];

  return (
      <div className="max-w-3xl mx-auto py-10">
          <div className="flex justify-between items-center mb-8">
              <span className="text-gray-500 font-medium">Question {currentQuestion + 1}/{activeQuiz.questions.length}</span>
              <span className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm font-bold">Score: {score}</span>
          </div>
          
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-200 mb-8 min-h-[200px] flex items-center justify-center text-center">
              <h3 className="text-2xl font-bold text-gray-800">{question.question}</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {question.options.map((opt, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleAnswer(idx)}
                    className="p-6 text-left bg-white border-2 border-gray-200 rounded-xl hover:border-indigo-600 hover:bg-indigo-50 transition-all font-semibold text-gray-700 flex items-center justify-between group"
                  >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gray-100 text-gray-500 flex items-center justify-center font-bold text-sm group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                            {String.fromCharCode(65 + idx)}
                        </div>
                        {opt}
                      </div>
                  </button>
              ))}
          </div>
      </div>
  );
};

export default QuizView;
