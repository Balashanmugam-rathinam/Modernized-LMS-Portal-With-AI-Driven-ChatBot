import React, { useState } from 'react';
import { User, AttendanceSession } from '../../types';
import { QrCode, Smartphone, RefreshCw, CheckCircle2 } from 'lucide-react';

interface AttendanceProps {
  user: User;
  sessions: AttendanceSession[];
  onMarkAttendance: (sessionId: string, studentId: string) => void;
  onCreateSession: (session: AttendanceSession) => void;
}

const Attendance: React.FC<AttendanceProps> = ({ user, sessions, onMarkAttendance, onCreateSession }) => {
  const [inputCode, setInputCode] = useState('');
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [activeSession, setActiveSession] = useState<AttendanceSession | null>(
    sessions.find(s => s.isActive) || null
  );

  const handleStudentSubmit = () => {
    // In a real app, this verifies against backend.
    // Here we check if the code matches any active session code.
    const session = sessions.find(s => s.isActive && s.code === inputCode);
    if (session) {
      onMarkAttendance(session.id, user.id);
      setStatus('success');
      setInputCode('');
    } else {
      setStatus('error');
    }
    setTimeout(() => setStatus('idle'), 3000);
  };

  const handleCreateSession = () => {
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    const newSession: AttendanceSession = {
      id: `sess-${Date.now()}`,
      code,
      courseId: 'CS101', // Default for demo
      date: new Date().toISOString(),
      isActive: true,
      attendees: []
    };
    onCreateSession(newSession);
    setActiveSession(newSession);
  };

  if (user.role === 'student') {
    return (
      <div className="max-w-md mx-auto mt-10">
        <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
          <div className="bg-indigo-600 p-6 text-center text-white">
            <Smartphone size={48} className="mx-auto mb-4 opacity-80" />
            <h2 className="text-2xl font-bold">Attendance Scanner</h2>
            <p className="text-indigo-200 text-sm mt-1">Enter the code displayed by your teacher.</p>
          </div>
          
          <div className="p-8">
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Session Code</label>
              <input
                type="text"
                maxLength={6}
                value={inputCode}
                onChange={e => setInputCode(e.target.value.toUpperCase())}
                placeholder="Ex: AB12CD"
                className="w-full text-center text-2xl tracking-widest border-2 border-gray-300 rounded-xl p-4 uppercase focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
              />
            </div>

            <button
              onClick={handleStudentSubmit}
              disabled={inputCode.length < 4}
              className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold py-4 rounded-xl shadow transition-all transform active:scale-95"
            >
              Mark Present
            </button>

            {status === 'success' && (
              <div className="mt-6 flex items-center justify-center gap-2 text-green-600 bg-green-50 p-3 rounded-lg animate-in fade-in slide-in-from-bottom-2">
                <CheckCircle2 size={20} /> Attendance Recorded!
              </div>
            )}
            
            {status === 'error' && (
              <div className="mt-6 text-center text-red-600 bg-red-50 p-3 rounded-lg">
                Invalid or expired code.
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Teacher View
  return (
    <div className="max-w-4xl mx-auto mt-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 flex flex-col items-center justify-center text-center">
            {activeSession ? (
                <>
                    <h3 className="text-lg font-semibold text-gray-500 mb-4">Active Session Code</h3>
                    <div className="text-7xl font-mono font-bold text-indigo-600 tracking-wider my-6">
                        {activeSession.code}
                    </div>
                    <div className="bg-white p-4 rounded-xl border-2 border-gray-200 mb-6">
                         <QrCode size={160} className="text-gray-900" />
                         {/* In real app, generate actual QR with qr.js */}
                    </div>
                    <p className="text-sm text-gray-500 mb-6">Ask students to scan this or enter the code.</p>
                    <button 
                        onClick={() => setActiveSession(null)}
                        className="text-red-600 hover:bg-red-50 px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                    >
                        End Session
                    </button>
                </>
            ) : (
                <>
                    <div className="w-20 h-20 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mb-6">
                        <RefreshCw size={32} />
                    </div>
                    <h2 className="text-2xl font-bold text-gray-900 mb-2">Start Attendance</h2>
                    <p className="text-gray-500 mb-8 max-w-xs">Generate a new session code for the current class.</p>
                    <button
                        onClick={handleCreateSession}
                        className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-8 rounded-xl shadow-lg transition-transform hover:-translate-y-1"
                    >
                        Generate Code
                    </button>
                </>
            )}
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
            <h3 className="font-bold text-lg mb-4">Recent Sessions</h3>
            <div className="space-y-3">
                {sessions.slice().reverse().map(sess => (
                    <div key={sess.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                        <div>
                            <p className="font-semibold text-gray-900">{sess.code}</p>
                            <p className="text-xs text-gray-500">{new Date(sess.date).toLocaleDateString()}</p>
                        </div>
                        <div className="flex items-center gap-2">
                             <span className={`px-2 py-1 rounded text-xs font-medium ${sess.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-200 text-gray-600'}`}>
                                {sess.isActive ? 'Active' : 'Closed'}
                             </span>
                             <span className="text-sm font-bold text-gray-700">{sess.attendees.length} Students</span>
                        </div>
                    </div>
                ))}
                {sessions.length === 0 && <p className="text-gray-400 text-center py-4">No sessions yet.</p>}
            </div>
        </div>
      </div>
    </div>
  );
};

export default Attendance;
