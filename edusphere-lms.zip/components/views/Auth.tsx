import React, { useState } from 'react';
import { User, Role } from '../../types';

interface AuthProps {
  onLogin: (user: User) => void;
  users: User[];
  onRegister: (newUser: User) => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin, users, onRegister }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('student@edusphere.com');
  const [password, setPassword] = useState('password');
  const [error, setError] = useState('');

  // Registration state
  const [regData, setRegData] = useState<Partial<User>>({
    role: 'student',
    name: '',
    email: '',
    phone: '',
    dob: '',
    parentIncome: '',
    community: 'General',
    courseName: '',
    gender: 'Male',
    guardianName: '',
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = users.find(u => u.email === email);
    // In a real app, verify password hash here. 
    // For this demo, we assume password 'password' is correct for mocked users.
    if (user && (password === 'password' || password.length > 0)) {
      onLogin(user);
    } else {
      setError('Invalid credentials. (Try student@edusphere.com / password)');
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    const newUser: User = {
      id: `user-${Date.now()}`,
      name: regData.name || 'New User',
      email: regData.email || '',
      role: regData.role || 'student',
      ...regData
    } as User;
    
    onRegister(newUser);
    onLogin(newUser);
  };

  const inputClass = "w-full bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block p-2.5";
  const labelClass = "block mb-1 text-sm font-medium text-gray-700";

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-100 to-purple-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md md:max-w-2xl overflow-hidden flex flex-col md:flex-row">
        
        {/* Banner Side */}
        <div className="hidden md:flex md:w-5/12 bg-indigo-600 p-8 flex-col justify-between text-white">
          <div>
            <h1 className="text-3xl font-bold mb-2">EduSphere</h1>
            <p className="text-indigo-200 text-sm">Empowering education through technology.</p>
          </div>
          <div className="space-y-4">
            <div className="bg-white/10 p-4 rounded-lg backdrop-blur-sm">
              <h3 className="font-semibold text-sm mb-1">Student Portal</h3>
              <p className="text-xs text-indigo-100">Access notes, check marks, and track attendance seamlessly.</p>
            </div>
          </div>
        </div>

        {/* Form Side */}
        <div className="w-full md:w-7/12 p-8 overflow-y-auto max-h-[90vh]">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center md:text-left">
            {isLogin ? 'Welcome Back' : 'Create Account'}
          </h2>
          
          {error && <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm mb-4">{error}</div>}

          {isLogin ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className={labelClass}>Email Address</label>
                <input 
                  type="email" 
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className={inputClass}
                  required 
                />
              </div>
              <div>
                <label className={labelClass}>Password</label>
                <input 
                  type="password" 
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className={inputClass}
                  required 
                />
              </div>
              <button 
                type="submit" 
                className="w-full text-white bg-indigo-600 hover:bg-indigo-700 focus:ring-4 focus:ring-indigo-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center transition-colors"
              >
                Sign In
              </button>
              <div className="text-sm text-center text-gray-500 mt-4">
                Don't have an account? <button type="button" onClick={() => setIsLogin(false)} className="text-indigo-600 hover:underline">Register</button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>Full Name</label>
                  <input type="text" className={inputClass} required value={regData.name} onChange={e => setRegData({...regData, name: e.target.value})} />
                </div>
                <div>
                    <label className={labelClass}>Email</label>
                    <input type="email" className={inputClass} required value={regData.email} onChange={e => setRegData({...regData, email: e.target.value})}/>
                </div>
                <div>
                  <label className={labelClass}>Phone</label>
                  <input type="tel" className={inputClass} value={regData.phone} onChange={e => setRegData({...regData, phone: e.target.value})}/>
                </div>
                <div>
                  <label className={labelClass}>Role</label>
                  <select className={inputClass} value={regData.role} onChange={e => setRegData({...regData, role: e.target.value as Role})}>
                    <option value="student">Student</option>
                    <option value="teacher">Teacher</option>
                  </select>
                </div>
              </div>

              {regData.role === 'student' && (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <label className={labelClass}>Date of Birth</label>
                      <input type="date" className={inputClass} value={regData.dob} onChange={e => setRegData({...regData, dob: e.target.value})}/>
                    </div>
                    <div>
                      <label className={labelClass}>Gender</label>
                      <select className={inputClass} value={regData.gender} onChange={e => setRegData({...regData, gender: e.target.value})}>
                        <option>Male</option>
                        <option>Female</option>
                        <option>Other</option>
                      </select>
                    </div>
                    <div>
                        <label className={labelClass}>Community</label>
                        <select className={inputClass} value={regData.community} onChange={e => setRegData({...regData, community: e.target.value})}>
                            <option>General</option>
                            <option>OBC</option>
                            <option>SC</option>
                            <option>ST</option>
                        </select>
                    </div>
                    <div>
                        <label className={labelClass}>Annual Parent Income</label>
                        <input type="number" className={inputClass} value={regData.parentIncome} onChange={e => setRegData({...regData, parentIncome: e.target.value})}/>
                    </div>
                  </div>
                  <div>
                    <label className={labelClass}>Course Name</label>
                    <input type="text" className={inputClass} placeholder="e.g. B.Tech CS" value={regData.courseName} onChange={e => setRegData({...regData, courseName: e.target.value})}/>
                  </div>
                </>
              )}

              <div className="pt-2">
                <button 
                    type="submit" 
                    className="w-full text-white bg-indigo-600 hover:bg-indigo-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center"
                >
                    Register
                </button>
                <div className="text-sm text-center text-gray-500 mt-2">
                    Already registered? <button type="button" onClick={() => setIsLogin(true)} className="text-indigo-600 hover:underline">Log in</button>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default Auth;
