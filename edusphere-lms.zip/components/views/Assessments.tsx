import React, { useState } from 'react';
import { User, Assessment } from '../../types';
import { Download, Edit2, Save, XCircle } from 'lucide-react';

interface AssessmentsProps {
  user: User;
  assessments: Assessment[];
  users: User[]; // to map student names for teachers
  onUpdateAssessment: (assessment: Assessment) => void;
}

const Assessments: React.FC<AssessmentsProps> = ({ user, assessments, users, onUpdateAssessment }) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<Assessment>>({});

  const handleEdit = (ass: Assessment) => {
    setEditingId(ass.id);
    setEditForm(ass);
  };

  const handleSave = () => {
    if (editingId && editForm) {
      // In a real app, merge properly
      const updated = { ...assessments.find(a => a.id === editingId)!, ...editForm } as Assessment;
      onUpdateAssessment(updated);
      setEditingId(null);
    }
  };

  if (user.role === 'student') {
    const myResults = assessments.filter(a => a.studentId === user.id);
    return (
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-gray-900">Academic Results</h2>
            <button className="flex items-center gap-2 text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-lg text-sm font-medium transition">
                <Download size={16} /> Download Report
            </button>
        </div>

        <div className="grid gap-4">
            {myResults.map(res => (
                <div key={res.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:shadow-md transition-shadow">
                    <div>
                        <h3 className="text-lg font-bold text-gray-800">{res.subject}</h3>
                        <p className="text-sm text-gray-500">Semester {res.semester}</p>
                    </div>
                    <div className="flex items-center gap-8">
                        <div className="text-center">
                            <span className="block text-xs text-gray-400 uppercase tracking-wider">Internal</span>
                            <span className="text-xl font-semibold text-gray-700">{res.continuousAssessment}/100</span>
                        </div>
                        <div className="text-center">
                            <span className="block text-xs text-gray-400 uppercase tracking-wider">End Sem</span>
                            <span className="text-xl font-bold text-indigo-600">{res.endSem}/100</span>
                        </div>
                        <div className="w-12 h-12 rounded-full border-4 border-indigo-100 flex items-center justify-center font-bold text-indigo-800 text-sm">
                            {Math.round((res.continuousAssessment + res.endSem) / 2)}%
                        </div>
                    </div>
                </div>
            ))}
        </div>
      </div>
    );
  }

  // Teacher View - Table Editor
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Student Grades</h2>
        <div className="flex gap-2">
            <button className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-200">Import CSV</button>
            <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700">Export Report</button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-gray-700 uppercase bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3">Student Name</th>
                <th className="px-6 py-3">Subject</th>
                <th className="px-6 py-3">Semester</th>
                <th className="px-6 py-3">Continuous Assessment</th>
                <th className="px-6 py-3">End Semester</th>
                <th className="px-6 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {assessments.map(ass => {
                const studentName = users.find(u => u.id === ass.studentId)?.name || 'Unknown';
                const isEditing = editingId === ass.id;
                
                return (
                  <tr key={ass.id} className="bg-white border-b hover:bg-gray-50">
                    <td className="px-6 py-4 font-medium text-gray-900">{studentName}</td>
                    <td className="px-6 py-4">{ass.subject}</td>
                    <td className="px-6 py-4">{ass.semester}</td>
                    <td className="px-6 py-4">
                        {isEditing ? (
                            <input 
                                type="number" 
                                className="w-20 border rounded px-2 py-1"
                                value={editForm.continuousAssessment}
                                onChange={e => setEditForm({...editForm, continuousAssessment: Number(e.target.value)})}
                            />
                        ) : ass.continuousAssessment}
                    </td>
                    <td className="px-6 py-4">
                         {isEditing ? (
                            <input 
                                type="number" 
                                className="w-20 border rounded px-2 py-1"
                                value={editForm.endSem}
                                onChange={e => setEditForm({...editForm, endSem: Number(e.target.value)})}
                            />
                        ) : ass.endSem}
                    </td>
                    <td className="px-6 py-4 text-right">
                        {isEditing ? (
                             <div className="flex justify-end gap-2">
                                <button onClick={handleSave} className="text-green-600 hover:text-green-800"><Save size={18} /></button>
                                <button onClick={() => setEditingId(null)} className="text-red-600 hover:text-red-800"><XCircle size={18} /></button>
                             </div>
                        ) : (
                            <button onClick={() => handleEdit(ass)} className="text-indigo-600 hover:text-indigo-800">
                                <Edit2 size={18} />
                            </button>
                        )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Assessments;
