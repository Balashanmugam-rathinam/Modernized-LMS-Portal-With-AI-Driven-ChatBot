import React from 'react';
import { User, Assessment, AttendanceSession } from '../../types';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';
import { Calendar, Clock, BookOpen, TrendingUp, AlertCircle } from 'lucide-react';

interface DashboardProps {
  user: User;
  assessments: Assessment[];
  sessions: AttendanceSession[];
}

const StudentDashboard: React.FC<DashboardProps> = ({ user, assessments, sessions }) => {
  // Mock calculations
  const myAssessments = assessments.filter(a => a.studentId === user.id);
  const avgScore = myAssessments.length 
    ? myAssessments.reduce((acc, curr) => acc + curr.endSem, 0) / myAssessments.length 
    : 0;

  // Attendance Calc
  const attendedSessions = sessions.filter(s => s.attendees.includes(user.id)).length;
  const totalSessions = sessions.length || 1; // avoid /0
  const attendancePerc = Math.round((attendedSessions / totalSessions) * 100);

  const data = [
    { name: 'Attended', value: attendedSessions },
    { name: 'Missed', value: totalSessions - attendedSessions },
  ];
  const COLORS = ['#4f46e5', '#e5e7eb'];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Welcome Card */}
        <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl p-6 text-white col-span-1 md:col-span-3">
          <h1 className="text-2xl font-bold mb-2">Welcome back, {user.name}!</h1>
          <p className="opacity-90">Course: {user.courseName} | Roll: {user.rollNumber}</p>
          <div className="mt-4 flex gap-4">
             <div className="bg-white/20 backdrop-blur rounded-lg px-4 py-2">
                <span className="block text-xs opacity-80">CGPA</span>
                <span className="text-xl font-bold">{(avgScore / 10).toFixed(1)}</span>
             </div>
             <div className="bg-white/20 backdrop-blur rounded-lg px-4 py-2">
                <span className="block text-xs opacity-80">Attendance</span>
                <span className="text-xl font-bold">{attendancePerc}%</span>
             </div>
          </div>
        </div>

        {/* Analytics */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-gray-500 text-sm font-medium mb-4 flex items-center gap-2">
            <Clock size={16} /> Attendance Overview
          </h3>
          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={data} innerRadius={40} outerRadius={60} paddingAngle={5} dataKey="value">
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="text-center text-sm text-gray-500">
             {attendedSessions} / {totalSessions} Sessions Attended
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 col-span-1 md:col-span-2">
           <h3 className="text-gray-500 text-sm font-medium mb-4 flex items-center gap-2">
            <TrendingUp size={16} /> Academic Performance
          </h3>
           <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={myAssessments}>
                <XAxis dataKey="subject" tick={{fontSize: 12}} interval={0} />
                <YAxis hide />
                <Tooltip cursor={{fill: 'transparent'}} />
                <Bar dataKey="endSem" fill="#4f46e5" radius={[4, 4, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
           </div>
        </div>
      </div>

      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
         <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
           <AlertCircle size={20} className="text-indigo-600"/> Upcoming Deadlines
         </h3>
         <div className="space-y-3">
            {[1, 2].map(i => (
                <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold">
                            {i * 12}
                        </div>
                        <div>
                            <p className="text-sm font-semibold text-gray-900">Assignment {i}: Advanced Algorithms</p>
                            <p className="text-xs text-gray-500">Due in {i + 1} days</p>
                        </div>
                    </div>
                    <button className="text-xs bg-white border border-gray-200 px-3 py-1 rounded-full hover:bg-gray-50">View</button>
                </div>
            ))}
         </div>
      </div>
    </div>
  );
};

const TeacherDashboard: React.FC<DashboardProps> = ({ user, sessions }) => {
  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-emerald-600 to-teal-600 rounded-2xl p-8 text-white">
        <h1 className="text-3xl font-bold mb-2">Hello, {user.name}</h1>
        <p className="opacity-90">Manage your classes, assessments, and students efficiently.</p>
        <div className="mt-6 flex flex-wrap gap-4">
            <button className="bg-white/20 hover:bg-white/30 transition-colors backdrop-blur rounded-lg px-6 py-3 font-semibold text-sm flex items-center gap-2">
                <BookOpen size={16} /> Create Session
            </button>
            <button className="bg-white/20 hover:bg-white/30 transition-colors backdrop-blur rounded-lg px-6 py-3 font-semibold text-sm flex items-center gap-2">
                <TrendingUp size={16} /> Update Marks
            </button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
         <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="text-gray-500 text-xs uppercase tracking-wide font-bold mb-2">Active Sessions</div>
            <div className="text-3xl font-bold text-gray-900">{sessions.filter(s => s.isActive).length}</div>
         </div>
         <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="text-gray-500 text-xs uppercase tracking-wide font-bold mb-2">Total Students</div>
            <div className="text-3xl font-bold text-gray-900">128</div>
         </div>
         <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="text-gray-500 text-xs uppercase tracking-wide font-bold mb-2">Pending Approvals</div>
            <div className="text-3xl font-bold text-gray-900">5</div>
         </div>
         <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="text-gray-500 text-xs uppercase tracking-wide font-bold mb-2">Avg. Attendance</div>
            <div className="text-3xl font-bold text-gray-900">88%</div>
         </div>
      </div>
    </div>
  );
};

const Dashboard: React.FC<DashboardProps> = (props) => {
  if (props.user.role === 'student') return <StudentDashboard {...props} />;
  return <TeacherDashboard {...props} />;
};

export default Dashboard;
