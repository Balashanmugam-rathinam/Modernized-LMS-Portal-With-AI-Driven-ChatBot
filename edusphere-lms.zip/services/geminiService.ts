import { GoogleGenAI } from "@google/genai";
import { User } from "../types";

const apiKey = process.env.API_KEY || ''; // Ensure this is set in your environment
const ai = new GoogleGenAI({ apiKey });

export const sendMessageToGemini = async (
  message: string,
  userContext: User,
  history: string[]
): Promise<string> => {
  try {
    const model = 'gemini-2.5-flash';
    
    const userRoleInfo = `User Name: ${userContext.name}, Role: ${userContext.role}.`;
    const systemPrompt = `
      You are the AI Assistant for EduSphere LMS. 
      Your goal is to help students and teachers navigate the platform, understand policies, and find information.
      
      Current User Context: ${userRoleInfo}
      
      Platform Capabilities:
      - Students: Mark attendance via code, View assessment marks, Upload/View notes, Take Quizzes, View Certificates.
      - Teachers: Create attendance sessions, Grade assessments, Approve notes.
      
      Guidelines:
      - Be helpful, concise, and professional.
      - If a student asks about marks, guide them to the 'Assessments' tab.
      - If a student asks about attendance, guide them to the 'Attendance' tab to scan/enter code.
      - If a user reports a bug, apologize and suggest contacting admin@edusphere.com.
      - Do not make up specific data (like "Your mark is 90") unless provided in the context (which is currently limited). Instead, tell them *where* to find it.
    `;

    // Construct a chat-like history for context (simplistic approach for single-turn or short context)
    const contents = [
        { role: 'user', parts: [{ text: systemPrompt }] }, // Inject system prompt as first turn or use systemInstruction if supported by specific call, but here content-injection is safe.
        ...history.map((msg, i) => ({
            role: i % 2 === 0 ? 'user' : 'model',
            parts: [{ text: msg }]
        })),
        { role: 'user', parts: [{ text: message }] }
    ];

    const response = await ai.models.generateContent({
      model: model,
      contents: {
          role: 'user',
          parts: [{ text: systemPrompt + "\n\nUser Query: " + message }]
      }
    });

    return response.text || "I'm having trouble connecting to the knowledge base right now.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Sorry, I am currently unable to process your request. Please try again later.";
  }
};
